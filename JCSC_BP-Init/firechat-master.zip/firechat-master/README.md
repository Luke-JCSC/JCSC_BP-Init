Firechat.js
===========

Simple, extensible chat built on [Firebase](https://www.firebase.com/?utm_source=readme&utm_medium=github&utm_campaign=firechat).

For demos, documentation, and integration instructions, see [http://firebase.github.io/firechat/](http://firebase.github.io/firechat/).
